class LocalDBRoutes {
  static const String userRoute = 'user';
  static const List<String> routes = [userRoute];
}