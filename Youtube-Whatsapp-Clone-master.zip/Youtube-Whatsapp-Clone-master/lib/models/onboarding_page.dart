class OnBoardingPageModel {
  final String image;
  final String heading;
  final String text;

  OnBoardingPageModel(this.image, this.heading, this.text);
}
